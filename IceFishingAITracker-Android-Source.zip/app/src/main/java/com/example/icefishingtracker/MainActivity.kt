package com.example.icefishingtracker
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
 private lateinit var token: EditText
 private lateinit var chat: EditText
 private lateinit var status: TextView
 private val prefs by lazy { getSharedPreferences("tracker", MODE_PRIVATE) }
 private val requestCode = 4102
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val box=LinearLayout(this).apply { orientation=1; setPadding(28,32,28,24) }
  box.addView(TextView(this).apply { text="IceFishing AI Tracker"; textSize=24f })
  box.addView(TextView(this).apply { text="Telegram credentials stay on this phone."; textSize=14f })
  token=EditText(this).apply { hint="Bot API token"; inputType=129; setText(prefs.getString("token","")) }
  chat=EditText(this).apply { hint="Numeric Telegram chat ID"; inputType=2; setText(prefs.getString("chat","")) }
  box.addView(token); box.addView(chat)
  box.addView(Button(this).apply { text="Save Telegram settings"; setOnClickListener {
   prefs.edit().putString("token",token.text.toString().trim()).putString("chat",chat.text.toString().trim()).apply()
   status.text="Settings saved locally."
  }})
  box.addView(Button(this).apply { text="Test Telegram"; setOnClickListener { testTelegram() } })
  box.addView(Button(this).apply { text="Start screen tracking"; setOnClickListener {
   if(token.text.isNullOrBlank()||chat.text.isNullOrBlank()) status.text="Enter and save Telegram settings first."
   else { val m=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; startActivityForResult(m.createScreenCaptureIntent(),requestCode) }
  }})
  box.addView(Button(this).apply { text="Stop tracking"; setOnClickListener { stopService(Intent(this@MainActivity,CaptureService::class.java)); status.text="Tracking stopped." } })
  status=TextView(this).apply { text="Ready. Screen capture starts only after your permission."; textSize=14f }; box.addView(status)
  box.addView(TextView(this).apply { text="OCR reads visible text only. It may not recognize graphical icons or hidden game data. No outcome prediction or betting."; textSize=12f })
  setContentView(ScrollView(this).apply { addView(box) })
 }
 private fun testTelegram() {
  val t=token.text.toString().trim(); val c=chat.text.toString().trim()
  if(t.isEmpty()||c.isEmpty()){status.text="Enter bot token and chat ID.";return}
  prefs.edit().putString("token",t).putString("chat",c).apply(); status.text="Testing..."
  thread { val msg=sendTelegram(t,c,"IceFishing AI Tracker connected."); runOnUiThread { status.text=msg } }
 }
 @Deprecated("Deprecated in Android API")
 override fun onActivityResult(req:Int,res:Int,data:Intent?) {
  super.onActivityResult(req,res,data)
  if(req==requestCode && res==Activity.RESULT_OK && data!=null) {
   startForegroundService(Intent(this,CaptureService::class.java).putExtra("resultCode",res).putExtra("data",data))
   status.text="Screen tracking started."
  } else if(req==requestCode) status.text="Screen capture permission not granted."
 }
 companion object {
  fun sendTelegram(token:String,chat:String,message:String):String = try {
   val conn=(URL("https://api.telegram.org/bot$token/sendMessage").openConnection() as HttpURLConnection).apply {
    requestMethod="POST"; doOutput=true; connectTimeout=10000; readTimeout=10000; setRequestProperty("Content-Type","application/json; charset=utf-8")
   }
   val body=JSONObject().put("chat_id",chat).put("text",message).toString()
   conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
   val response=conn.inputStream.bufferedReader().use{it.readText()}; conn.disconnect()
   if(JSONObject(response).optBoolean("ok")) "Telegram connection successful." else "Telegram API rejected the request."
  } catch(e:Exception) { "Telegram failed: ${e.message ?: "check token, chat ID and internet"}" }
 }
}
