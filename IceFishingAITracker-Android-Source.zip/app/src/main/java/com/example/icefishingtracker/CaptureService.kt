package com.example.icefishingtracker
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService:Service(){
 private var projection:MediaProjection?=null
 private var projectionCallback:MediaProjection.Callback?=null
 private var reader:ImageReader?=null
 private var display:VirtualDisplay?=null
 private var thread:HandlerThread?=null
 private val busy=AtomicBoolean(false)
 private val sent=HashSet<String>()
 private val recognizer by lazy{TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)}
 override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
  val channel="ice_tracker"; val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
  nm.createNotificationChannel(NotificationChannel(channel,"Screen tracking",NotificationManager.IMPORTANCE_LOW))
  startForeground(77,Notification.Builder(this,channel).setContentTitle("IceFishing AI Tracker").setContentText("Screen recognition active").setSmallIcon(android.R.drawable.ic_menu_view).build())
  val data=intent?.getParcelableExtra<Intent>("data")
  if(data!=null) begin(intent.getIntExtra("resultCode",0),data)
  return START_NOT_STICKY
 }
 @Suppress("DEPRECATION")
 private fun begin(code:Int,data:Intent){
  val mgr=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
  projection=mgr.getMediaProjection(code,data)
  val dm=DisplayMetrics(); (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
  thread=HandlerThread("screen-ocr").also{it.start()}; val handler=Handler(thread!!.looper)
  projectionCallback=object:MediaProjection.Callback(){ override fun onStop(){ stopSelf() } }
  projection!!.registerCallback(projectionCallback!!,handler)
  reader=ImageReader.newInstance(dm.widthPixels,dm.heightPixels,PixelFormat.RGBA_8888,2)
  reader!!.setOnImageAvailableListener({ src ->
   val image=src.acquireLatestImage() ?: return@setOnImageAvailableListener
   if(!busy.compareAndSet(false,true)){image.close();return@setOnImageAvailableListener}
   recognizer.process(InputImage.fromMediaImage(image,0)).addOnSuccessListener{ result ->
    val txt=result.text.lowercase()
    listOf("leaf","lil' blues","lil blues","big oranges","huge reds").filter{txt.contains(it)}.forEach{ label ->
     if(sent.add(label)){
      val p=getSharedPreferences("tracker",MODE_PRIVATE); val t=p.getString("token","")?:""; val c=p.getString("chat","")?:""
      if(t.isNotBlank()&&c.isNotBlank()) Thread{MainActivity.sendTelegram(t,c,"Visible game text detected: $label")}.start()
     }
    }
   }.addOnCompleteListener{image.close();busy.set(false)}
  },handler)
  display=projection!!.createVirtualDisplay("IceFishingTracker",dm.widthPixels,dm.heightPixels,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,handler)
 }
 override fun onDestroy(){display?.release();reader?.close();projection?.unregisterCallback(projectionCallback!!);projection?.stop();thread?.quitSafely();recognizer.close();stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy()}
 override fun onBind(intent:Intent?):IBinder?=null
}
