# IceFishing AI Tracker — Android starter

Builds a debug APK for Android 16 using GitHub Actions. It demonstrates user-approved MediaProjection screen capture, on-device ML Kit OCR, and Telegram `sendMessage` notifications.

## Limitations
- OCR recognizes visible text only; it may not recognize graphical fish icons or result animations. This starter does not read hidden game data or bypass platform protections.
- It records simple text detections, not a verified full result history, and cannot predict future outcomes.
- It never places bets.
- Telegram bot must be opened and `/start` sent by the user. This app sends messages; it is not a continuously running bot server.

## Build from an Android phone
1. Create an empty GitHub repository.
2. Extract this ZIP and upload its contents to the repository root.
3. Open **Actions** → **Build Android APK** → **Run workflow**.
4. When complete, open the workflow run and download artifact `IceFishingAITracker-debug`.
5. Extract the artifact and install `app-debug.apk`.

## Telegram
1. Open your bot and tap Start, then send `/start`.
2. Obtain your numeric chat ID using a trusted Telegram bot/chat-ID utility or your own `getUpdates` request. Never publish your token.
3. Enter the token and numeric chat ID in the app; tap Save and Test Telegram.

The token is stored in the app's private preferences on the device and is not embedded in the APK source.
